exports.saldoo = (prefix) => {
return `*── 「 Balance Brimo 」 ──*

*_》 Name : Muhammad Nadil Desei_*
*_》 Email : kazeyy67@gmail.com_*
*_》 Balance : 35.052.216_*
*_》 Point : 3509_*
*_》 Level : Basic_*
*_》 Pemasukan : 71.099.980_*
*_》 Pengeluaran : 36.047.764_*`
}