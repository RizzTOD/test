exports.totalfakechat = (prefix) => {
return `*_Total Fake Chat Ada 11 Tuan_*`
}

exports.totalunban = (prefix) => {
return `*_Total Text Unbanned Ada 21 Tuan_*`
}

exports.totalban = (prefix) => {
return `*_Total Text Banned 10 Tuan_*`
}