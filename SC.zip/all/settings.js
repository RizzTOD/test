const fs = require('fs')
const chalk = require('chalk')

global.owner = "6283172074754"
global.ownerStore = "6283172074754"
global.namabot = "RIZA OFFC"
global.namaCreator = "RIZA CRUEL"
global.namaStore = "Riza Offcial"
global.autoJoin = false
global.antilink = false
global.anticall = true
global.themeemoji = '🪀'
global.versisc = 'Private'
global.namasc = 'Private'
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.apitokendo = 'dop_v1_9a0906d0b316369de5ba2eec0ef74a045e8e2f22567eff00876bd2194132def1'
global.apilinode = '4cf9477e568f0a4414c2c6eba6767d251bd224a84d71437f10551ac3ed170890'
//SERVER 1
global.domain = 'https://aryahosting.cafegt.my.id' // Isi Domain Lu
global.apikey = 'ptla_xfGI3D7HScb4m9gBjaZt81Mz8E9LRlMGwX7YQHomRPx' // Isi Apikey Plta Lu
global.capikey = 'ptlc_pZWpdkyyv2cSHF37vJ295dOYhQ6qGdDlCcaUtPQgym2' // Isi Apikey Pltc Lu
//SERVER 2
global.domainn = 'https://admincrazy.amaliasyva-private.tech' // Isi Domain Lu
global.apikeyy = 'ptla_xfGI3D7HScb4m9gBjaZt81Mz8E9LRlMGwX7YQHomRPx' // Isi Apikey Plta Lu
global.capikeyy = 'ptlc_pZWpdkyyv2cSHF37vJ295dOYhQ6qGdDlCcaUtPQgym2' // Isi Apikey Pltc Lu
//SERVER 3
global.domainnn = 'https://ridhoxyz.tokodigital.software'
global.apikeyyy = 'ptla_YAjliZkkB1AT7yLPcpK6fWGg80NnTziBWeOnfRAvVPU'
global.capikeyyy = 'ptlc_wm9Ao3i60541LxA9Ud9Njy4wlaQPu7aLxleBKBg5nNs'
//BATAS
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "b36ab42975f5d28bcd26bc5c82c17c6a"
global.signature = "hash_hmac('sha256', $merchantCode.$channel.$merchantRef, $privateKey)"
global.merchant = "INV55567"
//MAU PEDIA
global.api_key = "iTn0HbFfeqHVgSEVVFGfRd6z26QuDntcqh0gWnExriecgS2F2PzHojNrgOySz85S"//@zallDev
global.api_id = "s0IJboQFZHznkYQ0"//@zallDev
global.secret = "h&gg#RafatharOffcial976*#"//@zallDev
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
global.thumb = fs.readFileSync("./thumb.png")
global.audionya = fs.readFileSync("./all/sound.mp3")
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
global.packname = ""
global.author = "Sticker By Riza Offcial"
global.jumlah = "5"
global.youtube = "*https://youtube.com/@RizaCruel*"
global.grup = "*https://chat.whatsapp.com/K33qq9EyFchCKgblkReXrD*"
global.telegram = "*https://t.me/RizaOfficial*"
global.instagram = "*https://instagram.com/alfi.boys1204*"
global.harga1 = "15k"
global.spekvps1 = "8gb Core 4"
global.vps1 = "Digital Ocean"
global.harga2 = "20k"
global.spekvps2 = "8gb Core 4"
global.vps2 = "Linode"
global.harga3 = "25k"
global.spekvps3 = "16gb Core 6"
global.vps3 = "Linode"
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})